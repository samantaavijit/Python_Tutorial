from setuptools import setup, find_packages
setup(name="packageAvijit", version="0.1", description="This is code with avijit package",
      long_description="This is a very very long description",
      auther="Avijit",
      packages=['packageAvijit'],
      install_requires=[])
